//
//De Arcade
//
//Final Project 
//by 
//Bernardus Jeffrey Darmawan
//2001585474
//Computer Science 2020, BINUS University
//


#include "declare.hpp"

int main()
{	
	UserData player;
	
	log_In(player); 
	
	chooseGame(player);

	return 0;
}
